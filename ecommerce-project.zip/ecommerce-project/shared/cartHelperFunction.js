let cartData = JSON.parse(localStorage.getItem("cart")) || [];

export function getCart() {
  console.log(cartData);

  return [...cartData];
}

export function saveCart(cart) {
  cartData = [...cart];
  localStorage.setItem("cart", JSON.stringify(cartData));
}

export function addToCart(
  productTitle,
  quantity = 1,
  price = 0,
  productId = null
) {
  const cart = getCart();

  const id = productId || generateProductId(productTitle);

  const existingItemIndex = cart.findIndex((item) => item.id === id);

  if (existingItemIndex > -1) {
    cart[existingItemIndex].quantity += quantity;
    cart[existingItemIndex].totalPrice =
      cart[existingItemIndex].quantity * cart[existingItemIndex].price;
  } else {
    const newItem = {
      id: id,
      title: productTitle,
      quantity: quantity,
      price: price,
      totalPrice: quantity * price,
      dateAdded: new Date().toISOString(),
    };
    cart.push(newItem);
  }

  saveCart(cart);

  alert(`Added to cart: ${productTitle} (Quantity: ${quantity})`);

  return cart.find((item) => item.id === id);
}

export function updateCartItemQuantity(productId, newQuantity) {
  const cart = getCart();
  const itemIndex = cart.findIndex((item) => item.id === productId);

  if (itemIndex > -1) {
    if (newQuantity <= 0) {
      return removeFromCart(productId);
    }

    cart[itemIndex].quantity = newQuantity;
    cart[itemIndex].totalPrice =
      cart[itemIndex].quantity * cart[itemIndex].price;
    saveCart(cart);
    return cart[itemIndex];
  }

  return null;
}

export function clearCart() {
  saveCart([]);
  alert("Cart cleared!");
}

export function getCartTotal() {
  const cart = getCart();
  return cart.reduce((total, item) => total + item.totalPrice, 0);
}

export function getCartItemCount() {
  const cart = getCart();
  return cart.reduce((count, item) => count + item.quantity, 0);
}

export function removeFromCart(productId) {
  const cart = getCart();
  const updatedCart = cart.filter((item) => item.id !== productId);
  saveCart(updatedCart);
  return updatedCart;
}

function generateProductId(title) {
  return (
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") +
    "-" +
    Date.now()
  );
}

export function findCartItem(productId) {
  const cart = getCart();
  return cart.find((item) => item.id === productId) || null;
}

function displayCartSummary() {
  const cart = getCart();
  const total = getCartTotal();
  const itemCount = getCartItemCount();

  console.log("=== CART SUMMARY ===");
  console.log(`Items: ${itemCount}`);
  console.log(`Total: $${total.toFixed(2)}`);
  console.log("Items in cart:");
  cart.forEach((item) => {
    console.log(
      `- ${item.title} (x${item.quantity}) - $${item.totalPrice.toFixed(2)}`
    );
  });
}

window.addToCart = function (
  productTitle,
  quantity = 1,
  price = 0,
  productId = null
) {
  return addToCart(productTitle, quantity, price, productId);
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    addToCart,
    removeFromCart,
    updateCartItemQuantity,
    clearCart,
    getCart,
    getCartTotal,
    getCartItemCount,
    findCartItem,
    displayCartSummary,
  };
}

window.cartHelpers = {
  addToCart,
  removeFromCart,
  updateCartItemQuantity,
  clearCart,
  getCart,
  getCartTotal,
  getCartItemCount,
  findCartItem,
  displayCartSummary,
};
