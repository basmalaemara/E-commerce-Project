let ordersData = JSON.parse(localStorage.getItem("orders")) || [];

function getOrders() {
  return [...ordersData];
}

function saveOrders(orders) {
  ordersData = [...orders];
  refreshOrdersDisplay();
}

function generateOrderId() {
  return (
    "ORD" + Date.now() + Math.random().toString(36).substr(2, 5).toUpperCase()
  );
}

/**
 * Clear all orders
 */
function clearAllOrders() {
  if (
    confirm(
      "Are you sure you want to delete all orders? This cannot be undone."
    )
  ) {
    saveOrders([]);
    alert("All orders cleared!");
  }
}

function formatOrderDate(isoDate) {
  const date = new Date(isoDate);
  return (
    date.toLocaleDateString() +
    " " +
    date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  );
}

function toggleOrderDetails(orderId) {
  const detailsElement = document.getElementById(`details-${orderId}`);
  const toggleButton = document.getElementById(`toggle-${orderId}`);

  if (detailsElement.classList.contains("hidden")) {
    detailsElement.classList.remove("hidden");
    toggleButton.textContent = "Hide Details";
  } else {
    detailsElement.classList.add("hidden");
    toggleButton.textContent = "Show Details";
  }
}

function refreshOrdersDisplay() {
  const orders = getOrders();
  const ordersContainer = document.getElementById("ordersContainer");
  const emptyOrders = document.getElementById("emptyOrders");

  if (!ordersContainer || !emptyOrders) {
    console.error("Orders display elements not found");
    return;
  }

  // Clear container
  ordersContainer.innerHTML = "";

  if (orders.length === 0) {
    emptyOrders.classList.remove("hidden");
  } else {
    emptyOrders.classList.add("hidden");
    console.log(orders);

    orders.forEach((order) => {
      const orderElement = document.createElement("div");
      orderElement.className = "bg-white rounded-lg shadow mb-4";

      orderElement.innerHTML = `
        
        <div id="details" class="hidden">
          <div class="p-4">
            <h4 class="font-semibold mb-3">Order Items:</h4>
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="border-b">
                    <th class="text-left py-2">Product</th>
                    <th class="text-left py-2">Quantity</th>
                    <th class="text-left py-2">Price</th>
                    <th class="text-left py-2">Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${order
                    .map(
                      (item) => `
                    <tr class="border-b">
                      <td class="py-2">${item.title}</td>
                      <td class="py-2">${item.quantity}</td>
                      <td class="py-2">$${item.price.toFixed(2)}</td>
                      <td class="py-2">$${item.totalPrice.toFixed(2)}</td>
                    </tr>
                  `
                    )
                    .join("")}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;

      ordersContainer.appendChild(orderElement);
    });
  }
}

function addSampleOrder() {
  const sampleItems = [
    {
      id: "sample-1",
      title: 'MacBook Pro 14"',
      quantity: 1,
      price: 1999,
      totalPrice: 1999,
    },
    {
      id: "sample-2",
      title: "Magic Mouse",
      quantity: 1,
      price: 79,
      totalPrice: 79,
    },
    {
      id: "sample-3",
      title: "USB-C Cable",
      quantity: 2,
      price: 19,
      totalPrice: 38,
    },
  ];

  addOrder(sampleItems);
  alert("Sample order added!");
}

function initializeOrdersPage() {
  // Refresh display on page load
  refreshOrdersDisplay();

  // Mobile menu toggle
  const menuToggle = document.getElementById("menuToggle");
  const mobileMenu = document.getElementById("mobileMenu");

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden");
    });
  }
}

// Make functions available globally
window.refreshOrdersDisplay = refreshOrdersDisplay;
window.toggleOrderDetails = toggleOrderDetails;
window.addSampleOrder = addSampleOrder;
window.clearAllOrders = clearAllOrders;

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", initializeOrdersPage);
