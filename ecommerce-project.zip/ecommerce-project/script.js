import { clearCurrentUser, getCurrentUser } from "../shared/storage.js";

const authBtn = document.getElementById("authBtn");
const welcomeMessage = document.getElementById("welcomeMessage");
const featuredContainer = document.getElementById("featuredProducts");

const user = getCurrentUser();
console.log("user", user);

if (user) {
  authBtn.textContent = "Logout";
  welcomeMessage.textContent = `Welcome to the E-Commerce App, ${user.username}`;
  authBtn.addEventListener("click", () => {
    clearCurrentUser();
    location.reload();
  });
} else {
  authBtn.textContent = "Login/Register";
  welcomeMessage.textContent = "Welcome to the E-Commerce App, Guest";
  authBtn.addEventListener("click", () => {
    window.location.href = "../auth/auth.html";
  });
}

function showLoader() {
  document.getElementById("loader")?.classList.remove("!hidden");
}

function hideLoader() {
  document.getElementById("loader")?.classList.add("!hidden");
}

const productContainer = document.getElementById("productContainer");
const searchInput = document.getElementById("searchInput");
// const categoryFilter = document.getElementById("categoryFilter");

let allProducts = [];

async function loadProducts() {
  try {
    showLoader();
    const res = await fetch("https://fakestoreapi.com/products");
    const products = await res.json();
    allProducts = products;
    displayProducts(products);
    // populateCategories(products);
  } catch (error) {
    productContainer.innerHTML = "<p>Error loading products.</p>";
    console.log(error);
  } finally {
    hideLoader();
  }
}

function displayProducts(products) {
  productContainer.innerHTML = "";
  products.forEach((product) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="h-96 mb-3 relative overflow-hidden rounded-2xl group bg-white">
         <img class="rounded-2xl w-full h-full object-contain" src="${product.image}" alt="${product.title}">
     
      <div class="transition duration-500 absolute bottom-0 translate-y-full group-hover:translate-y-0 left-0 w-full z-40 px-12 py-2 flex items-center gap-2">
        <button class="add-to-cart bg-neutral-100 cursor-pointer px-4 py-2 rounded-2xl grow text-lg" data-id="${product.id}" title="Add to Cart">Add to cart</button>
        <button class="quick-view bg-neutral-100 cursor-pointer p-3 rounded-2xl" data-id="${product.id}" title="Quick View">👁️</button>
      </div>
     </div>
    
      <h3 class="text-xl font-semibold">${product.title}</h3>
      <p class=" text-lg text-neutral-600">$${product.price}</p>
    `;
    productContainer.appendChild(card);
  });

  document.querySelectorAll(".add-to-cart").forEach((icon) => {
    icon.addEventListener("click", (e) => {
      const id = +e.target.dataset.id;
      const product = allProducts.find((p) => p.id === id);
      addToCart(product);
    });
  });

  document.querySelectorAll(".quick-view").forEach((icon) => {
    icon.addEventListener("click", (e) => {
      const id = +e.target.dataset.id;
      const product = allProducts.find((p) => p.id === id);
      openQuickView(product);
    });
  });
}

// function populateCategories(products) {
//   const categories = [...new Set(products.map((p) => p.category))];
//   categories.forEach((cat) => {
//     const option = document.createElement("option");
//     option.value = cat;
//     option.textContent = cat;
//     categoryFilter.appendChild(option);
//   });
// }

searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.toLowerCase();
  const filtered = allProducts.filter((p) =>
    p.title.toLowerCase().includes(keyword)
  );
  displayProducts(filtered);
});

// categoryFilter.addEventListener("change", () => {
//   const selected = categoryFilter.value;
//   const filtered = selected
//     ? allProducts.filter((p) => p.category === selected)
//     : allProducts;
//   displayProducts(filtered);
// });

function addToCart(product, qty = 1) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const existing = cart.find((p) => p.id === product.id);
  if (existing) {
    existing.quantity += qty;
  } else {
    cart.push({ ...product, quantity: qty });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${product.title} added to cart!`);
}

function openQuickView(product) {
  document.getElementById("modalImage").src = product.image;
  document.getElementById("modalTitle").textContent = product.title;
  document.getElementById("modalPrice").textContent = "$" + product.price;
  document.getElementById("modalDesc").textContent = product.description;
  document.getElementById("modalRating").textContent =
    product.rating?.rate || "N/A";
  document.getElementById("modalQty").value = 1;

  document.getElementById("modalAddToCart").onclick = function () {
    const qty = parseInt(document.getElementById("modalQty").value);
    addToCart(product, qty);
    document.getElementById("quickViewModal").style.display = "none";
  };

  document.getElementById("quickViewModal").style.display = "grid";
}

document
  .querySelector("#quickViewModal .close-btn")
  .addEventListener("click", () => {
    document.getElementById("quickViewModal").style.display = "none";
  });

window.addEventListener("click", (e) => {
  if (e.target.id === "quickViewModal") {
    document.getElementById("quickViewModal").style.display = "none";
  }
});
const toggle = document.getElementById("menuToggle");
const menu = document.getElementById("mobileMenu");
const mobileLoginBtn = document.getElementById("authBtnMobile");

toggle.addEventListener("click", () => {
  menu.classList.toggle("hidden");
});

mobileLoginBtn.addEventListener("click", () => {
  if (user) {
    clearCurrentUser();
    location.reload();
  } else {
    window.location.href = "../auth/auth.html";
  }
});

loadProducts();
