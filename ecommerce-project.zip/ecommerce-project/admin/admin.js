import { clearCurrentUser, getCurrentUser } from "../shared/storage.js";

const orders = [
  {
    id: 1,
    user: "ali@example.com",
    title: "Product 1",
    total: 80.5,
    status: "Pending",
  },
  {
    id: 2,
    user: "sara@example.com",
    title: "Product 2",
    total: 45,
    status: "Shipped",
  },
  {
    id: 3,
    user: "hassan@example.com",
    title: "Product 3",
    total: 129.99,
    status: "Delivered",
  },
];

const API_KEY = "products";
const form = document.getElementById("productForm");
const productIdInput = document.getElementById("productId");
const titleInput = document.getElementById("productTitle");
const priceInput = document.getElementById("productPrice");
const categoryInput = document.getElementById("productCategory");
const imageInput = document.getElementById("productImage");
const adminProductList = document.getElementById("adminProductList");
const addBtn = document.getElementById("saveProductBtn");
const updateBtn = document.getElementById("updateProductBtn");
const authBtn = document.getElementById("authBtn");
const filterStatus = document.getElementById("statusFilter");

let products = [];

[titleInput, priceInput, categoryInput, imageInput].forEach((input) => {
  input.addEventListener("input", () => {
    input.classList.remove("is-invalid");
  });
});

function isExists(title, currentId = -1) {
  return products.some(
    (p, index) =>
      index !== currentId &&
      p.title.trim().toLowerCase() === title.trim().toLowerCase()
  );
}

const user = getCurrentUser();
if (user) {
  authBtn.textContent = "Logout";
  authBtn.addEventListener("click", () => {
    clearCurrentUser();
    location.reload();
  });
} else {
  authBtn.textContent = "Login/Register";
  authBtn.addEventListener("click", () => {
    window.location.href = "../auth/auth.html";
  });
}
if (!user || !user.isAdmin) {
  alert("Admins only!");
  window.location.href = "../index.html";
}

function validateForm() {
  let valid = true;

  const title = titleInput.value.trim();
  const price = priceInput.value.trim();
  const category = categoryInput.value.trim();
  const image = imageInput.value.trim();

  const id = parseInt(productIdInput.value);
  if (!title) {
    titleInput.classList.add("is-invalid");
    valid = false;
  } else if (isExists(title, id)) {
    titleInput.classList.add("is-invalid");
    titleInput.nextElementSibling.textContent = "This product already exists.";
    valid = false;
  } else {
    titleInput.classList.remove("is-invalid");
    titleInput.nextElementSibling.textContent = "Please enter a product title.";
  }

  if (!price || isNaN(price) || parseFloat(price) <= 0) {
    priceInput.classList.add("is-invalid");
    valid = false;
  } else {
    priceInput.classList.remove("is-invalid");
  }

  if (!category) {
    categoryInput.classList.add("is-invalid");
    valid = false;
  } else {
    categoryInput.classList.remove("is-invalid");
  }

  if (!image || !image.startsWith("http")) {
    imageInput.classList.add("is-invalid");
    valid = false;
  } else {
    imageInput.classList.remove("is-invalid");
  }

  return valid;
}

function CategoryOptions() {
  const datalist = document.getElementById("categoryList");
  datalist.innerHTML = "";

  const uniqueCategories = [...new Set(products.map((p) => p.category))];
  uniqueCategories.forEach((cat) => {
    const option = document.createElement("option");
    option.value = cat;
    datalist.appendChild(option);
  });
}

async function loadProducts() {
  const stored = localStorage.getItem(API_KEY);

  try {
    showLoader();
    if (stored) {
      products = JSON.parse(stored);
      renderProducts();
      CategoryOptions();
    } else {
      try {
        const res = await fetch("https://fakestoreapi.com/products");
        const apiProducts = await res.json();

        products = apiProducts.map((p) => ({
          title: p.title,
          price: p.price,
          category: p.category,
          image: p.image,
        }));

        saveProducts();
        renderProducts();
        CategoryOptions();
      } catch (err) {
        console.error("Failed to fetch API products:", err);
      }
    }
  } catch (err) {
    console.error("Error loading products:", err);
  } finally {
    hideLoader();
  }
}

function saveProducts() {
  localStorage.setItem(API_KEY, JSON.stringify(products));
}

function showLoader() {
  document.getElementById("loader")?.classList.remove("!hidden");
}

function hideLoader() {
  document.getElementById("loader")?.classList.add("!hidden");
}

function renderProducts() {
  adminProductList.innerHTML = "";
  const fragment = document.createDocumentFragment();

  products.forEach((product, index) => {
    const col = document.createElement("div");
    col.className = "col-md-4";

    const card = document.createElement("div");
    card.className = "card h-100";

    const img = document.createElement("img");
    img.src = product.image;
    img.className = "card-img-top";
    img.style = "object-fit: contain; height: 250px; background: #f9f9f9";

    const cardBody = document.createElement("div");
    cardBody.className = "card-body";

    const title = document.createElement("h5");
    title.className = "card-title";
    title.textContent = product.title;

    const price = document.createElement("p");
    price.className = "card-text";
    price.textContent = `$${product.price}`;

    const category = document.createElement("p");
    category.className = "card-text text-muted";
    category.textContent = product.category;

    const btnGroup = document.createElement("div");
    btnGroup.className = "d-flex justify-content-between mt-3";

    const editBtn = document.createElement("button");
    editBtn.className = "btn btn-sm btn-primary";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => editProduct(index));

    const deleteBtn = document.createElement("button");
    deleteBtn.className = "btn btn-sm btn-danger";
    deleteBtn.textContent = "Delete";
    deleteBtn.addEventListener("click", () => deleteProduct(index));

    btnGroup.append(editBtn, deleteBtn);
    cardBody.append(title, price, category, btnGroup);
    card.append(img, cardBody);
    col.appendChild(card);
    fragment.appendChild(col);
  });

  adminProductList.appendChild(fragment);
  renderMetrics();
  renderOrders();
  renderCategoryChart();
  renderRevenueByCategoryChart();
}

function renderMetrics() {
  document.getElementById("productCount").textContent = products.length;
  document.getElementById("orderCount").textContent = orders.length;

  const totalSales = orders.reduce((sum, o) => sum + o.total, 0);
  document.getElementById("totalSales").textContent = `$${totalSales.toFixed(
    2
  )}`;

  const users = [...new Set(orders.map((o) => o.user))];
  document.getElementById("activeUsers").textContent = users.length;
}

function renderCategoryChart() {
  const ctx = document.getElementById("categoryChart");
  if (!ctx) return;

  const categoryCount = {};
  products.forEach((p) => {
    categoryCount[p.category] = (categoryCount[p.category] || 0) + 1;
  });

  const data = {
    labels: Object.keys(categoryCount),
    datasets: [
      {
        label: "Category Share",
        data: Object.values(categoryCount),
        backgroundColor: [
          "#007bff",
          "#28a745",
          "#ffc107",
          "#dc3545",
          "#6f42c1",
          "#17a2b8",
        ],
      },
    ],
  };

  new Chart(ctx, {
    type: "pie",
    data,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "bottom",
        },
      },
    },
  });
}

// ----- Chart 1: Order Status Breakdown -----
function renderOrderStatusChart() {
  const orderStatusCounts = { Pending: 0, Shipped: 0, Delivered: 0 };

  orders.forEach((order) => {
    orderStatusCounts[order.status] =
      (orderStatusCounts[order.status] || 0) + 1;
  });

  new Chart(document.getElementById("orderStatusChart"), {
    type: "doughnut",
    data: {
      labels: Object.keys(orderStatusCounts),
      datasets: [
        {
          label: "Orders",
          data: Object.values(orderStatusCounts),
          backgroundColor: ["#f39c12", "#3498db", "#2ecc71"],
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom" },
      },
    },
  });
}

function renderRevenueByCategoryChart() {
  const ctx = document.getElementById("revenueByCategoryChart");
  if (!ctx) return;

  const revenueByCategory = {};

  // Sum revenue per product category based on order totals
  orders.forEach((order) => {
    const matchedProduct = products.find((p) => p.title === order.title);
    if (matchedProduct) {
      const category = matchedProduct.category;
      revenueByCategory[category] =
        (revenueByCategory[category] || 0) + order.total;
    }
  });

  const data = {
    labels: Object.keys(revenueByCategory),
    datasets: [
      {
        label: "Revenue",
        data: Object.values(revenueByCategory),
        backgroundColor: [
          "#6f42c1",
          "#ffc107",
          "#20c997",
          "#e83e8c",
          "#17a2b8",
          "#fd7e14",
        ],
      },
    ],
  };

  new Chart(ctx, {
    type: "pie",
    data,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "bottom",
        },
      },
    },
  });
}

function renderOrders(orderList = orders) {
  const tbody = document.getElementById("orderTable");
  tbody.innerHTML = "";

  orderList.forEach((order, index) => {
    const tr = document.createElement("tr");

    const tdId = document.createElement("td");
    tdId.textContent = order.id;

    const tdUser = document.createElement("td");
    tdUser.textContent = order.user;

    const tdTotal = document.createElement("td");
    tdTotal.textContent = `$${order.total}`;

    const tdStatus = document.createElement("td");
    tdStatus.textContent = order.status;

    const tdUpdate = document.createElement("td");
    const btn = document.createElement("button");
    btn.className = "btn btn-sm btn-outline-secondary";
    btn.textContent = "Next";
    btn.onclick = () => {
      order.status = getNextStatus(order.status);
      saveOrders();
      renderOrders();
      renderMetrics();
    };

    tdUpdate.appendChild(btn);
    tr.append(tdId, tdUser, tdTotal, tdStatus, tdUpdate);
    tbody.appendChild(tr);
  });
  renderOrderStatusChart();
}

function saveOrders() {
  localStorage.setItem("admin_orders", JSON.stringify(orders));
}

function loadOrders() {
  const stored = localStorage.getItem("admin_orders");
  orders = stored ? JSON.parse(stored) : [];
  renderOrders(orders);
}

function getNextStatus(current) {
  const flow = ["Pending", "Shipped", "Delivered"];
  const i = flow.indexOf(current);
  renderOrderStatusChart();
  return flow[i + 1] || "Delivered";
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!validateForm()) return;

  const title = titleInput.value.trim();
  const price = parseFloat(priceInput.value);
  const category = categoryInput.value.trim();
  const image = imageInput.value.trim();
  const id = productIdInput.value;

  if (id) {
    products[id] = { title, price, category, image };
  } else {
    products.push({ title, price, category, image });
  }

  saveProducts();
  renderProducts();
  form.reset();
  productIdInput.value = "";
  updateBtn.classList.add("!hidden");
  addBtn.classList.remove("!hidden");
});

window.editProduct = function (index) {
  const p = products[index];
  productIdInput.value = index;
  titleInput.value = p.title;
  priceInput.value = p.price;
  categoryInput.value = p.category;
  imageInput.value = p.image;
  updateBtn.classList.remove("!hidden");
  addBtn.classList.add("!hidden");
};

updateBtn.addEventListener("click", (e) => {
  e.preventDefault();
  if (!validateForm()) return;

  const id = parseInt(productIdInput.value);
  if (isNaN(id) || id < 0 || id >= products.length) return;

  const title = titleInput.value.trim();
  const price = parseFloat(priceInput.value);
  const category = categoryInput.value.trim();
  const image = imageInput.value.trim();

  products[id] = { title, price, category, image };

  saveProducts();
  renderProducts();
  form.reset();
  productIdInput.value = "";

  updateBtn.classList.add("!hidden");
  addBtn.classList.remove("!hidden");
});

window.deleteProduct = function (index) {
  if (confirm("Delete this product?")) {
    products.splice(index, 1);
    saveProducts();
    renderProducts();
  }
};

filterStatus.addEventListener("change", () => {
  const selected = filterStatus.value;
  const filtered = selected
    ? orders.filter((o) => o.status === selected)
    : orders;
  renderOrders(filtered);
});

loadProducts();
loadOrders();
