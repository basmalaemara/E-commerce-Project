import { addToCart } from "../shared/cartHelperFunction.js";
import { clearCurrentUser, getCurrentUser } from "../shared/storage.js";
const productList = document.getElementById("productContainer");
const searchInput = document.getElementById("searchInput");
const authBtn = document.getElementById("authBtn");

const user = getCurrentUser();
if (user) {
  authBtn.textContent = "Logout";
  authBtn.addEventListener("click", () => {
    clearCurrentUser();
    location.reload();
  });
} else {
  authBtn.textContent = "Login/Register";
  authBtn.addEventListener("click", () => {
    window.location.href = "../auth/auth.html";
  });
}

let products = [];

const API_KEY = "products";

function showLoader() {
  document.getElementById("loader")?.classList.remove("d-none");
}

function hideLoader() {
  document.getElementById("loader")?.classList.add("d-none");
}

async function loadProducts() {
  showLoader();
  const stored = localStorage.getItem(API_KEY);

  try {
    if (stored) {
      products = JSON.parse(stored);
      renderProducts(products);
    } else {
      try {
        const res = await fetch("https://fakestoreapi.com/products");
        const apiProducts = await res.json();

        products = apiProducts.map((p) => ({
          title: p.title,
          price: p.price,
          category: p.category,
          image: p.image,
        }));

        localStorage.setItem(API_KEY, JSON.stringify(products));

        renderProducts(products);
      } catch (err) {
        productList.innerHTML =
          '<p class="text-danger">Failed to load products.</p>';
      }
    }
  } catch (err) {
    productList.innerHTML =
      '<p class="text-danger">Error loading products.</p>';
  } finally {
    hideLoader();
  }
}

function renderProducts(productArray) {
  productList.innerHTML = "";
  const fragment = document.createDocumentFragment();

  productArray.forEach((product) => {
    const col = document.createElement("div");

    const card = document.createElement("div");
    card.className = "h-full";

    const img = document.createElement("img");
    img.src = product.image;
    img.className = "w-full object-contain h-[250px] bg-white rounded-lg mb-2";

    const cardBody = document.createElement("div");
    cardBody.className = "card-body";

    const category = document.createElement("p");
    category.className = "card-text text-neutral-400";
    category.textContent = product.category;

    const title = document.createElement("h5");
    title.className = "card-title text-xl line-clamp-2";
    title.textContent = product.title;

    const price = document.createElement("p");
    price.className = "card-text text-lg font-bold mb-2";
    price.textContent = `$${product.price}`;

    const qtyWrapper = document.createElement("div");
    qtyWrapper.className =
      "input-group mb-2 bg-white flex justify-between items-center";

    const minusBtn = document.createElement("button");
    minusBtn.className = "bg-neutral-950 text-white p-2 rounded-md";
    minusBtn.textContent = "−";

    const qtyInput = document.createElement("input");
    qtyInput.type = "number";
    qtyInput.value = 1;
    qtyInput.min = 1;
    qtyInput.className = "form-control text-center ";
    qtyInput.style.maxWidth = "60px";

    const plusBtn = document.createElement("button");
    plusBtn.className = "bg-neutral-950 text-white p-2 rounded-md";
    plusBtn.textContent = "+";

    minusBtn.onclick = () => {
      if (parseInt(qtyInput.value) > 1) {
        qtyInput.value = parseInt(qtyInput.value) - 1;
      }
    };

    plusBtn.onclick = () => {
      qtyInput.value = parseInt(qtyInput.value) + 1;
    };

    qtyWrapper.append(minusBtn, qtyInput, plusBtn);

    const addBtn = document.createElement("button");
    addBtn.className = "bg-neutral-950 text-white p-2 rounded-md w-full";
    addBtn.textContent = "Add to Cart";
    addBtn.onclick = () =>
      addToCart(
        product.title,
        parseInt(qtyInput.value),
        product.price,
        product.id
      );

    cardBody.append(category, title, price, qtyWrapper, addBtn);
    card.append(img, cardBody);
    col.appendChild(card);
    fragment.appendChild(col);
  });

  productList.appendChild(fragment);
}

searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.toLowerCase();
  const filtered = products.filter((p) =>
    p.title.toLowerCase().includes(keyword)
  );
  renderProducts(filtered);
});

function renderCategoryFilter() {
  const categories = [...new Set(products.map((p) => p.category))];
  const select = document.getElementById("categoryFilter");
  select.innerHTML =
    `<option value="">All Categories</option>` +
    categories.map((c) => `<option value="${c}">${c}</option>`).join("");

  select.addEventListener("change", () => {
    const selected = select.value;
    const filtered = selected
      ? products.filter((p) => p.category === selected)
      : products;
    renderProducts(filtered);
  });
}

window.addToCart = function (productTitle, quantity, price, id) {
  addToCart(productTitle, quantity, price, id);
};

loadProducts();
loadProducts().then(() => renderCategoryFilter());
