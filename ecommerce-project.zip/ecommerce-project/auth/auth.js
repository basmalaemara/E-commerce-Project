import { setCurrentUser } from "../shared/storage.js";
document.addEventListener("DOMContentLoaded", () => {
  // --- ELEMENT SELECTORS ---
  const loginView = document.getElementById("login-view");
  const signupView = document.getElementById("signup-view");
  const loggedInView = document.getElementById("logged-in-view");
  const successView = document.getElementById("success-view");
  const adminCheckboxContainer = document.getElementById(
    "admin-checkbox-container"
  ); // Selector for checkbox container
  const signupForm = document.getElementById("signup-form");
  const loginForm = document.getElementById("login-form");
  const showSignupBtn = document.getElementById("show-signup-btn");
  const showLoginBtn = document.getElementById("show-login-btn");
  const logoutButton = document.getElementById("logout-button");
  const welcomeMessage = document.getElementById("welcome-message");
  const adminLinkContainer = document.getElementById("admin-link-container");
  const signupUsername = document.getElementById("signup-username");
  const signupEmail = document.getElementById("signup-email");
  const signupPassword = document.getElementById("signup-password");
  const signupSubmitBtn = document.getElementById("signup-submit-btn");
  const usernameValidationMsg = document.getElementById(
    "username-validation-message"
  );
  const emailValidationMsg = document.getElementById(
    "email-validation-message"
  );
  const passwordValidationMsg = document.getElementById(
    "password-validation-message"
  );

  // --- REGEX DEFINITIONS ---
  const REGEX = {
    username: /^[a-zA-Z0-9_-]{3,15}$/,
    email: /^[a-zA-Z0-9._-]+@(gmail\.com|yahoo\.com)$/,
    password:
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
  };

  const validationStatus = { username: false, email: false, password: false };

  // --- UTILITY & LOGIC FUNCTIONS ---
  const getUsers = () => JSON.parse(localStorage.getItem("users")) || [];

  /**
   * Checks localStorage to see if an admin account already exists.
   * Hides the "Register as Admin" checkbox if one is found.
   */
  const updateAdminCheckboxVisibility = () => {
    const adminExists = getUsers().some((user) => user.isAdmin);
    adminCheckboxContainer.classList.toggle("d-none", adminExists);
  };

  const checkFormValidity = () => {
    const isFormValid =
      validationStatus.username &&
      validationStatus.email &&
      validationStatus.password;
    signupSubmitBtn.disabled = !isFormValid;
  };

  const setValidationUI = (input, messageEl, isValid, validMsg, invalidMsg) => {
    messageEl.textContent = isValid ? validMsg : invalidMsg;
    messageEl.className = `validation-message ${
      isValid ? "valid-message" : "invalid-message"
    }`;
    input.className = isValid ? "valid-input" : "invalid-input";
  };

  // --- REAL-TIME VALIDATION LISTENERS (No changes here) ---
  signupUsername.addEventListener("input", () => {
    const value = signupUsername.value;
    const users = getUsers();

    validationStatus.username =
      REGEX.username.test(value) &&
      !users.some((u) => u.username.toLowerCase() === value.toLowerCase());
    setValidationUI(
      signupUsername,
      usernameValidationMsg,
      validationStatus.username,
      "Username is available!",
      REGEX.username.test(value)
        ? "Username is already taken."
        : "Invalid format (3-15 chars, a-z, 0-9, _, -)."
    );
    checkFormValidity();
  });
  signupEmail.addEventListener("input", () => {
    const value = signupEmail.value;
    const users = getUsers();
    validationStatus.email =
      REGEX.email.test(value) &&
      !users.some((u) => u.email.toLowerCase() === value.toLowerCase());
    setValidationUI(
      signupEmail,
      emailValidationMsg,
      validationStatus.email,
      "Email is valid!",
      REGEX.email.test(value)
        ? "Email is already registered."
        : "Must be a valid @gmail.com or @yahoo.com address."
    );
    checkFormValidity();
  });
  signupPassword.addEventListener("input", () => {
    const value = signupPassword.value;
    validationStatus.password = REGEX.password.test(value);
    setValidationUI(
      signupPassword,
      passwordValidationMsg,
      validationStatus.password,
      "Password strength is sufficient.",
      "8+ chars, 1 upper, 1 lower, 1 num, 1 symbol."
    );
    checkFormValidity();
  });

  // --- FORM SUBMISSION & NAVIGATION ---
  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (signupSubmitBtn.disabled) return;

    const users = getUsers();
    // The value of isAdmin is read here. It will be false if the checkbox is hidden.
    const isAdmin = document.getElementById("signup-isAdmin").checked;

    users.push({
      username: signupUsername.value,
      email: signupEmail.value,
      password: signupPassword.value,
      isAdmin: isAdmin,
    });
    localStorage.setItem("users", JSON.stringify(users));

    updateView(successView); // Show success message
    setTimeout(() => {
      // Then redirect after a delay
      updateView(loginView);
      signupForm.reset();
      Object.keys(validationStatus).forEach(
        (key) => (validationStatus[key] = false)
      );
      [signupUsername, signupEmail, signupPassword].forEach(
        (el) => (el.className = "")
      );
      [
        usernameValidationMsg,
        emailValidationMsg,
        passwordValidationMsg,
      ].forEach((el) => {
        el.textContent = "";
        el.className = "validation-message";
      });
      checkFormValidity();
    }, 2500);
  });

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const user = getUsers().find(
      (u) =>
        u.email === document.getElementById("login-email").value &&
        u.password === document.getElementById("login-password").value
    );
    console.log("value", user);

    if (user) {
      initializeUI(user);
    } else {
      alert("Invalid email or password."); // This could be improved, but is kept for simplicity
    }
  });

  logoutButton.addEventListener("click", () => {
    initializeUI(user);
  });

  // --- UI VIEW MANAGEMENT ---
  const updateView = (viewToShow) => {
    [loginView, signupView, loggedInView, successView].forEach((view) =>
      view.classList.add("d-none")
    );
    if (viewToShow) viewToShow.classList.remove("d-none");
  };

  showSignupBtn.addEventListener("click", () => {
    // *** THIS IS THE KEY STEP ***
    // Before showing the signup form, check if we should display the admin checkbox.
    updateAdminCheckboxVisibility();
    updateView(signupView);
  });

  showLoginBtn.addEventListener("click", () => {
    updateView(loginView);
  });

  // --- INITIALIZATION ---
  const initializeUI = (user) => {
    if (user) {
      // *** CHANGE: Check if the already-logged-in user is an admin ***
      if (user.isAdmin) {
        // If admin, show the logged-in view on this page
        updateView(loggedInView);
        welcomeMessage.textContent = `Welcome, ${user.username}!`;
        setCurrentUser(user); // Save current user with 'remember me' option
        window.location.href = "../admin/admin.html";
        adminLinkContainer.classList.remove("d-none"); // Show the admin link
      } else {
        // If not an admin, redirect them away from the login page
        window.location.href = "../index.html"; // <-- REDIRECTS TO THE NEW URL
      }
    } else {
      // If no one is logged in, show the login form
      updateView(loginView);
    }
  };

  initializeUI(); // Run on page load
});
