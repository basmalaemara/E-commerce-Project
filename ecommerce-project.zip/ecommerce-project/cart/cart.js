import {
  clearCart,
  findCartItem,
  getCart,
  getCartItemCount,
  getCartTotal,
  removeFromCart,
  updateCartItemQuantity,
} from "../shared/cartHelperFunction.js";

function refreshCartDisplay() {
  const cart = getCart();
  const tableBody = document.getElementById("cartTableBody");
  const emptyCart = document.getElementById("emptyCart");
  const totalItems = document.getElementById("totalItems");
  const totalPrice = document.getElementById("totalPrice");

  if (!tableBody || !emptyCart || !totalItems) {
    console.error("Cart display elements not found");
    return;
  }

  tableBody.innerHTML = "";

  if (cart.length === 0) {
    emptyCart.classList.remove("hidden");
    tableBody.parentElement.querySelector("thead").classList.add("hidden");
  } else {
    emptyCart.classList.add("hidden");
    tableBody.parentElement.querySelector("thead").classList.remove("hidden");

    cart.forEach((item) => {
      const row = document.createElement("tr");
      row.className = "border-b hover:bg-gray-50";
      row.innerHTML = `
                <td class="p-4 font-medium">${item.title}</td>
                <td class="p-4">
                    <input type="number" value="${item.quantity}" min="1" 
                           class="w-20 border border-gray-300 rounded px-2 py-1 text-center" 
                           onchange="handleQuantityChange('${
                             item.id
                           }', parseInt(this.value))">
                </td>
                <td class="p-4">$${item.price.toFixed(2)}</td>
                <td class="p-4 font-semibold">$${(
                  item.price * item.quantity
                ).toFixed(2)}</td>
                <td class="p-4">
                    <button onclick="handleRemoveItem('${item.id}')" 
                            class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm transition">
                        Remove
                    </button>
                </td>
            `;
      tableBody.appendChild(row);
    });
  }

  // Update summary
  totalItems.textContent = getCartItemCount();
  totalPrice.textContent = getCartTotal().toFixed(2);
}

function handleQuantityChange(productId, newQuantity) {
  if (isNaN(newQuantity) || newQuantity < 0) {
    alert("Please enter a valid quantity");
    refreshCartDisplay(); // Reset the input
    return;
  }

  updateCartItemQuantity(productId, newQuantity);
}

function handleRemoveItem(productId) {
  const item = findCartItem(productId);
  if (item && confirm(`Remove "${item.title}" from cart?`)) {
    removeFromCart(productId);
    refreshCartDisplay();
  }
}

function initializeCartPage() {
  refreshCartDisplay();

  const clearBtn = document.querySelector('button[onclick="clearCart()"]');
  if (clearBtn) {
    clearBtn.onclick = () => {
      if (confirm("Are you sure you want to clear your cart?")) {
        clearCart();
        refreshCartDisplay();
      }
    };
  }

  const refreshBtn = document.querySelector(
    'button[onclick="refreshCartDisplay()"]'
  );
  if (refreshBtn) {
    refreshBtn.onclick = refreshCartDisplay;
  }

  const menuToggle = document.getElementById("menuToggle");
  const mobileMenu = document.getElementById("mobileMenu");

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden");
    });
  }
}

function checkout() {
  const cart = getCart();
  if (cart.length === 0) {
    alert("Your cart is empty. Please add items before checking out.");
    return;
  }

  if (localStorage.getItem("orders") != null) {
    const existingOrders = JSON.parse(localStorage.getItem("orders"));
    existingOrders.push(cart);
    localStorage.setItem("orders", JSON.stringify(existingOrders));
  } else {
    localStorage.setItem("orders", JSON.stringify([cart]));
  }

  clearCart();
  alert("Checkout successful! Your order has been placed.");
  window.location.href = "../order/order.html";
}

window.checkout = checkout;
window.handleQuantityChange = handleQuantityChange;
window.handleRemoveItem = handleRemoveItem;

initializeCartPage();

if (typeof window.addToCart === "function") {
  const originalAddToCart = window.addToCart;
  window.addToCart = function (
    productTitle,
    quantity = 1,
    price = 0,
    productId = null
  ) {
    const result = originalAddToCart(productTitle, quantity, price, productId);
    refreshCartDisplay();
    return result;
  };
}
