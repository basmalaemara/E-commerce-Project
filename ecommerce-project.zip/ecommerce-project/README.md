# 🛍️ E-Commerce Web App

A basic e-commerce website built using **HTML**, **CSS**, and **Vanilla JavaScript**. The project includes core functionality like user authentication, a product catalog fetched from an external API, shopping cart management, order tracking, and optional admin capabilities.

## 📌 Objective

To create a dynamic browser-based shopping experience using only front-end technologies, with all data stored locally using `localStorage`.

---

## 🚀 Features

### ✅ Core Features

1. **Authentication**
   - Signup, Login, and Logout functionality
   - Stores user info in `localStorage` (`username`, `email`, `password`, `isAdmin`)
   - Admin-only page access protection

2. **Product Catalog**
   - Product listing as cards with image, title, and price
   - Fetches data from [FakeStore API](https://fakestoreapi.com/products)
   - Search by keyword
   - Filter by category
   - Admin can Add, Edit, or Delete products (optional)

3. **Shopping Cart & Orders**
   - Add items to cart
   - View cart with quantities and total
   - Complete checkout (clears cart and generates order with unique ID)
   - View past orders from `localStorage`

4. **Admin Dashboard** *(Optional)*
   - Accessible only to admin users (`isAdmin = true`)
   - Displays total sales, user count, product count
   - Allows CRUD operations on products and orders

---

## 📁 Folder Structure

```
ecommerce-project/
│
├── auth/
│   ├── auth.html
│   ├── auth.css
│   └── auth.js
│
├── products/
│   ├── products.html
│   ├── products.css
│   └── products.js
│
├── cart/
│   ├── cart.html
│   ├── cart.css
│   ├── cart.js
│
├── order/ 
│   ├── order.html
│   ├── order.css
│   └── order.js
│
├── admin/ *(optional)*
│   ├── admin.html
│   ├── admin.css
│   └── admin.js
│
├── shared/
│   ├── storage.js
│   └── cartHelperFunctions.js
│
└── index.html
└── style.css
└── script.js

```

---

## 🛠 Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone https://github.com/your-username/ecommerce-project.git
   cd ecommerce-project
   ```

2. **Open `index.html` or any page in a live server or browser**

> No server or database setup is needed – all data is stored in the browser's `localStorage`.


